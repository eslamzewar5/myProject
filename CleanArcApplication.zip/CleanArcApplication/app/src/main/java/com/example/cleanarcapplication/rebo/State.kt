package com.example.cleanarcapplication.rebo

data class State (var email: String = "",
    var password : String = "",
    var loading : Boolean =false)