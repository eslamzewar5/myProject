package com.example.cleanarcapplication.ui

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cleanarcapplication.rebo.AuthAction
import com.example.cleanarcapplication.rebo.AuthRepositoryImpl
import com.example.cleanarcapplication.rebo.State
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor(private var repo : AuthRepositoryImpl): ViewModel(){

     var _state = MutableStateFlow(State())

      fun onAction(authAction: AuthAction){
//          when(authAction){
////              AuthAction.LogIn ->
////              AuthAction.Register ->
//          }
      }
    fun login(email : String,password: String,activity: Activity){
        viewModelScope.launch { repo.loginMethod(email, password,activity   ) }
    }

    fun register(email : String,password: String,activity: Activity){
        viewModelScope.launch { repo.loginMethod(email, password,activity   ) }
    }
}