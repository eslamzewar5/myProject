package com.example.cleanarcapplication.rebo

import android.app.Activity

interface AuthRepository {

    fun loginMethod(email : String,password: String,activity: Activity)
    fun signupMethod(email : String,password: String)
    fun isCurrentExist() : Boolean
    fun  getUserId() : String
}