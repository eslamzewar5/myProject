package com.example.cleanarcapplication.rebo

sealed interface AuthAction {
    data object LogIn : AuthAction
    data object Register : AuthAction
}