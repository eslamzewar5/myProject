package com.example.cleanarcapplication.rebo

import com.example.cleanarcapplication.R
import android.app.Activity
import androidx.navigation.findNavController
import com.google.firebase.auth.FirebaseAuth
import javax.inject.Inject

class AuthRepositoryImpl @Inject constructor(private val auth : FirebaseAuth) : AuthRepository {
    override fun loginMethod(email : String,password: String,activity: Activity )  {
     auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener {
         if (it.isSuccessful){
             activity.findNavController(R.id.fragmentContainerView).navigate(R.id.action_authFragment_to_signupFragment)
         }
     }
    }

    override fun signupMethod(email : String,password: String) {

    }

    override fun isCurrentExist(): Boolean {
         return auth.currentUser?.uid !=null
    }

    override fun getUserId(): String {
        return if (isCurrentExist()) auth.currentUser?.uid!!
        else ""
    }
}